/**
 * Companies.gs — Company Analysis (module 15)
 * Central contractor/company register: pending-status companies, companies
 * missing an account number, GIFMIS linkage status, ownership records.
 */

function listCompanies(filters) {
  requirePermission_('companies', 'read');
  return applyFilters_(readAll_('Companies'), filters);
}

function saveCompany(record) {
  requirePermission_('companies', 'write');
  if (record._row) {
    updateRecord_('Companies', record._row, record);
    logAudit_('company_updated', 'companies', record.id, '');
  } else {
    record.id = genId_('CO');
    record.status = record.status || 'Pending';
    record.createdAt = nowIso_();
    appendRecord_('Companies', record);
    logAudit_('company_created', 'companies', record.id, record.name || '');
  }
  invalidateCache_('companies');
  return { ok: true, id: record.id };
}

function getCompanyAnalysis(filters) {
  requirePermission_('companies', 'read');
  var companies = applyFilters_(readAll_('Companies'), filters);
  return {
    total: companies.length,
    pending: companies.filter(function (c) { return c.status === 'Pending'; }),
    missingAccountNumber: companies.filter(function (c) { return !c.accountNumber; }),
    gifmisNotLinked: companies.filter(function (c) { return !c.gifmisLinked || c.gifmisLinked === 'FALSE'; }),
    all: companies
  };
}

function deleteCompany(id) {
  requirePermission_('companies', 'write');
  var rows = readAll_('Companies');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Company not found: ' + id);
  deleteRow_('Companies', row._row);
  invalidateCache_('companies');
  logAudit_('company_deleted', 'companies', id, '');
  return true;
}

/** The fixed 14-item compliance/document checklist requested for every
 *  company. Same one-slot-per-type pattern as Contract Documents. */
var COMPANY_DOC_TYPES = [
  'CAC Certificate', 'Status Report', 'MEMART', 'TCC (Tax Clearance Certificate)', 'PENCOM',
  'ITF', 'BPP', 'NSITF', 'Audited Accounts', 'Affidavit', 'Reference Letter',
  'Lease/Equipment', 'CV/Resume', 'Similar Jobs (Award Letters & JCC)'
];

function getCompanyDocumentChecklist(companyId) {
  requirePermission_('companies', 'read');
  var existing = readAll_('CompanyDocuments').filter(function (d) { return d.companyId === companyId; });
  return COMPANY_DOC_TYPES.map(function (docType) {
    var match = existing.filter(function (d) { return d.docType === docType; })[0];
    return { docType: docType, id: match ? match.id : null, driveLink: match ? match.driveLink : '', filename: match ? match.filename : '', notes: match ? match.notes : '', uploadedAt: match ? match.uploadedAt : '' };
  });
}

function uploadCompanyDocument(companyId, docType, base64Data, mimeType, filename) {
  requirePermission_('companies', 'write');
  if (COMPANY_DOC_TYPES.indexOf(docType) === -1) throw new Error('Unknown document type: ' + docType);
  var user = getCurrentUser();
  var uploaded = uploadEvidence(base64Data, mimeType, filename, 'Companies', 'companyDocuments');
  var existing = readAll_('CompanyDocuments').filter(function (d) { return d.companyId === companyId && d.docType === docType; })[0];
  if (existing) {
    updateRecord_('CompanyDocuments', existing._row, { driveLink: uploaded.url, filename: filename, uploadedAt: nowIso_(), uploadedBy: user.email });
  } else {
    appendRecord_('CompanyDocuments', { id: genId_('COD'), companyId: companyId, docType: docType, driveLink: uploaded.url, filename: filename, uploadedAt: nowIso_(), uploadedBy: user.email });
  }
  logAudit_('company_document_uploaded', 'companies', companyId, docType);
  return true;
}

/** The "Manual Entry" counterpart to uploadCompanyDocument — typed
 *  information instead of a file. Same one-slot-per-doc-type row; entering
 *  manual text does not require or replace a file, and vice versa. */
function saveCompanyDocumentNote(companyId, docType, notes) {
  requirePermission_('companies', 'write');
  if (COMPANY_DOC_TYPES.indexOf(docType) === -1) throw new Error('Unknown document type: ' + docType);
  var user = getCurrentUser();
  var existing = readAll_('CompanyDocuments').filter(function (d) { return d.companyId === companyId && d.docType === docType; })[0];
  if (existing) {
    updateRecord_('CompanyDocuments', existing._row, { notes: notes, uploadedAt: nowIso_(), uploadedBy: user.email });
  } else {
    appendRecord_('CompanyDocuments', { id: genId_('COD'), companyId: companyId, docType: docType, driveLink: '', filename: '', notes: notes, uploadedAt: nowIso_(), uploadedBy: user.email });
  }
  logAudit_('company_document_note_saved', 'companies', companyId, docType);
  return true;
}

function deleteCompanyDocument(id) {
  requirePermission_('companies', 'write');
  var rows = readAll_('CompanyDocuments');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Document not found: ' + id);
  deleteRow_('CompanyDocuments', row._row);
  logAudit_('company_document_deleted', 'companies', id, '');
  return true;
}
